.. _api-index:

###################
  The PyZMQ API
###################

.. htmlonly::

    :Release: |release|
    :Date: |today|

.. include:: generated/gen.rst
